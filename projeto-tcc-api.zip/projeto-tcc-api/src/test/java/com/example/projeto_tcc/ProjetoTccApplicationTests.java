package com.example.projeto_tcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoTccApplicationTests {

	@Test
	void contextLoads() {
	}

}
