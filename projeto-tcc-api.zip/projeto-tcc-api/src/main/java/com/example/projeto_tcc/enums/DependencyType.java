package com.example.projeto_tcc.enums;

public enum DependencyType {
    FINISH_TO_START,FINISH_TO_FINISH, START_TO_START,START_TO_FINISH
}
