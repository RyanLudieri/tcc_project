package com.example.projeto_tcc.util;

public class ParsedResourceUsage {
    public String roleName;
    public String activityName;
    public int quantityUsed;
}
