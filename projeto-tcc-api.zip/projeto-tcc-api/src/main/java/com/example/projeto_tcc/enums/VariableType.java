package com.example.projeto_tcc.enums;

public enum VariableType {
    INDEPENDENT,
    DEPENDENT,
    INTERMEDIATE
}
