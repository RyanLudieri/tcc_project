package com.example.projeto_tcc.enums;

public enum ObserverMethodElementType {
    NONE, LENGTH ,TIME, STATIONARY
}
