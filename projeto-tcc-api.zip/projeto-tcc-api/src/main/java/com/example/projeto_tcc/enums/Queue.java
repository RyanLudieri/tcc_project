package com.example.projeto_tcc.enums;

public enum Queue {
    FIFO,
    LIFO,
    PRIORITY,
    ROUND_ROBIN
}
