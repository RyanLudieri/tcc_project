package com.example.projeto_tcc.enums;


public enum IterationBehavior {
    MOVE_BACK, MOVE_FORWARD
}