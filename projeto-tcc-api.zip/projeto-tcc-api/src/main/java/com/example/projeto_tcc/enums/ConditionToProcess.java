package com.example.projeto_tcc.enums;

public enum ConditionToProcess {
    ALL_ENTITIES_AVAILABLE,SINGLE_ENTITY_AVAILABLE
}
