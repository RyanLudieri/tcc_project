package com.example.projeto_tcc.enums;

public enum ObserverActivityType {
    NONE, ACTIVE, DELAY, PROCESSOR
}
