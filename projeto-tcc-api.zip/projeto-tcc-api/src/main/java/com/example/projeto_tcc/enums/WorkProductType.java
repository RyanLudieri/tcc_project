package com.example.projeto_tcc.enums;

public enum WorkProductType {
    MAP, PROCESS
}
