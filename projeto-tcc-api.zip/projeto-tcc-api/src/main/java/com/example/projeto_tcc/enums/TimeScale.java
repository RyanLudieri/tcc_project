package com.example.projeto_tcc.enums;

public enum TimeScale {
    SECONDS,
    MINUTES,
    HOURS,
    DAYS
}

