package com.example.projeto_tcc.repository;

import com.example.projeto_tcc.entity.Observer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ObserverRepository extends JpaRepository<Observer, Long> {
}
